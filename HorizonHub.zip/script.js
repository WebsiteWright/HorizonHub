function showFortune() {
    const fortunes = [
        "A new country means new opportunities!",
        "You will find great success in your new home.",
        "Migration is the first step to a brighter future.",
        "Big adventures await you!"
    ];
    const randomFortune = fortunes[Math.floor(Math.random() * fortunes.length)];
    document.getElementById("fortune").innerText = randomFortune;
}

function spinWheel() {
    const rewards = ["Free Visa Consultation", "Discount on Travel Tickets", "Exclusive Country Guide", "Free Immigration Webinar"];
    const result = rewards[Math.floor(Math.random() * rewards.length)];
    document.getElementById("wheel-result").innerText = "You won: " + result;
}
